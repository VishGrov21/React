import React from 'react';
import './App.css';
import Keypad from './Keypad'

function App(props) {

	return (<Keypad/>);

}

export default App;
