import React, {Component} from 'react';
import ButtonStyles from './keypad.module.css';
import Result from './Result';

class Keypad extends Component {
	constructor() {
		super();

		this.state = {
			keyPress: ""
		}
	}

	clickHandler = (event) => {
		this.setState({keyPress: event.target.value})
	}

	render() {
		var numAndOperators = [
			[
				'7', '8', '9', '+',
			],
			[
				'4', '5', '6', '-',
			],
			[
				'1', '2', '3', 'x',
			],
			[
				'%', '0', '=', '/',
			],
		];
		var cAndCE = ['C', 'CE',]

		return (
			<div >
				<Result keyPress={this.state.keyPress}/>
				<button onClick={this.clickHandler} className={ButtonStyles.cAndCE} value={cAndCE[0]}>{cAndCE[0]}</button>
				<button onClick={this.clickHandler} className={ButtonStyles.cAndCE} value={cAndCE[1]}>{cAndCE[1]}</button>
				{
					numAndOperators.map((rowValue, rowIndex) => {
						return <div>
							{
								rowValue.map((colValue, colIndex) => {
									return <button onClick={this.clickHandler} className={ButtonStyles.button} value={colValue} key={rowIndex + "" + colIndex}>{colValue}</button>
								})

							}
							<br></br>
						</div>
					})
				}

			</div>
		)
	}
}

export default Keypad
