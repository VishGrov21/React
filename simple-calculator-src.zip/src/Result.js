import React from 'react'

class Result extends React.Component {

	// Setting the state of the class
	state = {
		result: ""
	}

	// This method is called when the any of the Calculator button is clicked
	buttonClicked = () => {
		let button = this.props.keyPress
		// If button clicked is '=' then provide the result
		if (button === "=") {
			this.calculate()
		} else if (button === "C") {
			// If button clicked is 'C' then clear the contents
			this.reset()
		} else if (button === "CE") {
			// If button clicked is 'CE' then clear the eliminate the last element
			this.backspace()
		} else {
			this.setState({
				// If neither of the above options then set the result state to hold the existing values provided during button clicked
				result: this.state.result + "" + button
			})
			console.log("Result = " + this.state.result)
		}
	};

	// This method is called when 'C' button is clicked
	reset = () => {
		this.setState({result: ""})
	};
	// This method is called when 'CE' button is clicked
	backspace = () => {
		this.setState({
			result: this.state.result.slice(0, -1)
		})
	};
	// This method is called when '=' button is clicked
	calculate = () => {
		try {
			this.setState({
				result: (eval(this.state.result) || "") + ""
			});
		} catch (e) {
			this.setState({keyPress: "Error"});
		}
	}
	render() {
		return (<div>
			{console.log(this.state.result)}
			{
				// If keyPress from props is true then call buttonClciked Function
				this.props.keyPress.length > 0
					? this.buttonClicked
					: null
			}
			<p>{this.state.result}</p>
		</div>)
	}
}

export default Result
